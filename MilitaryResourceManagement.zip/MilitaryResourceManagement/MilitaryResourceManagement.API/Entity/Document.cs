﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MilitaryResourceManagement.API.Entity
{
    [Table("Documents")]
    public class Document
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required(ErrorMessage = "Title is required")]
        [StringLength(100, ErrorMessage = "Title cannot be longer than 100 characters")]
        public string Title { get; set; }

        [Required(ErrorMessage = "File URL is required")]
        [StringLength(200, ErrorMessage = "File URL cannot be longer than 200 characters")]
        public string FileUrl { get; set; }

        public ICollection<Equipment>? Equipments { get; set; }
        public ICollection<Personnel>? Personnels { get; set; }
    }


}