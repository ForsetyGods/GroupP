﻿using MilitaryResourceManagement.API.Enum;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MilitaryResourceManagement.API.Entity
{
    [Table("Personnels")]
    public class Personnel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required(ErrorMessage = "First Name is required")]
        [StringLength(50, ErrorMessage = "First Name cannot be longer than 50 characters")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required")]
        [StringLength(50, ErrorMessage = "Last Name cannot be longer than 50 characters")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Birth Date is required")]
        public DateTime BirthDate { get; set; }

        [Required(ErrorMessage = "Rank is required")]
        [EnumDataType(typeof(Rank), ErrorMessage = "Invalid rank")]
        public Rank Rank { get; set; }

        public int? DocumentId { get; set; }

        [ForeignKey("DocumentId")]
        public Document Document { get; set; }
    }

}
