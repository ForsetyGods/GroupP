﻿using MilitaryResourceManagement.API.Enum;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace MilitaryResourceManagement.API.Entity
{
    [Table("Equipments")]
    public class Equipment
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, ErrorMessage = "Name cannot be longer than 100 characters")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Type is required")]
        [StringLength(50, ErrorMessage = "Type cannot be longer than 50 characters")]
        public string Type { get; set; }

        [Required(ErrorMessage = "ReleaseDate is required")]
        public DateTime ReleaseDate { get; set; }

        [Required(ErrorMessage = "Status is required")]
        [EnumDataType(typeof(EquipmentStatus), ErrorMessage = "Invalid status")]
        public EquipmentStatus Status { get; set; }

        public int? DocumentId { get; set; }

        [ForeignKey("DocumentId")]
        public Document Document { get; set; }

        public ICollection<Finance> Finances { get; set; }
    }
}
