﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;


namespace MilitaryResourceManagement.API.Migrations
{
    /// <inheritdoc />
    public partial class SeedInitial1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Documents",
                columns: new[] { "Id", "FileUrl", "Title" },
                values: new object[,]
                {
                    { 1, "url_to_file1", "Operations Manual" },
                    { 2, "url_to_file2", "Maintenance Records" }
                });

            migrationBuilder.InsertData(
                table: "Equipments",
                columns: new[] { "Id", "DocumentId", "Name", "ReleaseDate", "Status", "Type" },
                values: new object[,]
                {
                    { 1, 1, "Tank", new DateTime(2024, 5, 22, 21, 21, 59, 442, DateTimeKind.Local).AddTicks(4771), 0, "Vehicle" },
                    { 2, 2, "Jet Fighter", new DateTime(2024, 5, 22, 21, 21, 59, 442, DateTimeKind.Local).AddTicks(4804), 1, "Aircraft" }
                });

            migrationBuilder.InsertData(
                table: "Personnels",
                columns: new[] { "Id", "BirthDate", "DocumentId", "FirstName", "LastName", "Rank" },
                values: new object[,]
                {
                    { 1, new DateTime(1994, 5, 22, 21, 21, 59, 442, DateTimeKind.Local).AddTicks(4820), 1, "John", "Doe", 3 },
                    { 2, new DateTime(1999, 5, 22, 21, 21, 59, 442, DateTimeKind.Local).AddTicks(4825), 2, "Jane", "Doe", 1 }
                });

            migrationBuilder.InsertData(
                table: "Finances",
                columns: new[] { "Id", "Amount", "Date", "Description", "EquipmentId" },
                values: new object[,]
                {
                    { 1, 1000.00m, new DateTime(2024, 5, 22, 21, 21, 59, 442, DateTimeKind.Local).AddTicks(4840), "Purchase of equipment", 1 },
                    { 2, 500.00m, new DateTime(2024, 5, 22, 21, 21, 59, 442, DateTimeKind.Local).AddTicks(4843), "Maintenance expenses", 2 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Documents",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Documents",
                keyColumn: "Id",
                keyValue: 2);
        }
    }
}
