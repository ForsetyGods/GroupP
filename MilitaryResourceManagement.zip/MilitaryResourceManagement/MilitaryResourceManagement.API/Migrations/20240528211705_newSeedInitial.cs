﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace MilitaryResourceManagement.API.Migrations
{
    /// <inheritdoc />
    public partial class newSeedInitial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Documents",
                columns: new[] { "Id", "FileUrl", "Title" },
                values: new object[,]
                {
                    { 3, "url_to_file3", "Health and Safety Protocol" },
                    { 4, "url_to_file4", "Training Manual" },
                    { 5, "url_to_file5", "Logistics Overview" },
                    { 6, "url_to_file6", "Deployment Guidelines" },
                    { 7, "url_to_file7", "Equipment Usage Policy" },
                    { 8, "url_to_file8", "HR Policies" },
                    { 9, "url_to_file9", "Operational Strategies" },
                    { 10, "url_to_file10", "Communication Protocols" },
                    { 11, "url_to_file11", "IT Security Procedures" },
                    { 12, "url_to_file12", "Emergency Response Plan" }
                });

            migrationBuilder.UpdateData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 1,
                column: "ReleaseDate",
                value: new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9266));

            migrationBuilder.UpdateData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 2,
                column: "ReleaseDate",
                value: new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9313));

            migrationBuilder.UpdateData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 1,
                column: "Date",
                value: new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9517));

            migrationBuilder.UpdateData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 2,
                column: "Date",
                value: new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9522));

            migrationBuilder.UpdateData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 1,
                column: "BirthDate",
                value: new DateTime(1994, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9383));

            migrationBuilder.UpdateData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 2,
                column: "BirthDate",
                value: new DateTime(1999, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9392));

            migrationBuilder.InsertData(
                table: "Equipments",
                columns: new[] { "Id", "DocumentId", "Name", "ReleaseDate", "Status", "Type" },
                values: new object[,]
                {
                    { 3, 3, "Submarine", new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9318), 0, "Naval" },
                    { 4, 4, "Rifle", new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9322), 0, "Weapon" },
                    { 5, 5, "Helicopter", new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9326), 1, "Aircraft" },
                    { 6, 6, "Armored Vehicle", new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9331), 0, "Vehicle" },
                    { 7, 7, "Drone", new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9334), 0, "Aircraft" },
                    { 8, 8, "Missile", new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9339), 2, "Weapon" },
                    { 9, 9, "Warship", new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9343), 0, "Naval" },
                    { 10, 10, "Artillery", new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9347), 0, "Weapon" },
                    { 11, 11, "Cargo Truck", new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9351), 1, "Vehicle" },
                    { 12, 12, "Field Hospital", new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9355), 0, "Support" }
                });

            migrationBuilder.InsertData(
                table: "Personnels",
                columns: new[] { "Id", "BirthDate", "DocumentId", "FirstName", "LastName", "Rank" },
                values: new object[,]
                {
                    { 3, new DateTime(2002, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9397), 3, "Alice", "Wonder", 2 },
                    { 4, new DateTime(1989, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9401), 4, "Bob", "Builder", 4 },
                    { 5, new DateTime(1996, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9406), 5, "Charlie", "Day", 4 },
                    { 6, new DateTime(1992, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9410), 6, "Diana", "Prince", 6 },
                    { 7, new DateTime(1995, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9414), 7, "Edward", "Scissorhands", 0 },
                    { 8, new DateTime(1998, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9418), 8, "Fiona", "Shrek", 3 },
                    { 9, new DateTime(2000, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9471), 9, "George", "Jungle", 1 },
                    { 10, new DateTime(2003, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9476), 10, "Hannah", "Montana", 2 },
                    { 11, new DateTime(1990, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9481), 11, "Ian", "Mckellen", 4 },
                    { 12, new DateTime(1997, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9485), 12, "Julia", "Roberts", 5 }
                });

            migrationBuilder.InsertData(
                table: "Finances",
                columns: new[] { "Id", "Amount", "Date", "Description", "EquipmentId" },
                values: new object[,]
                {
                    { 3, 1200.00m, new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9525), "Operational costs", 3 },
                    { 4, 750.00m, new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9528), "Repair services", 4 },
                    { 5, 250.00m, new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9531), "Fuel expenses", 5 },
                    { 6, 300.00m, new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9534), "Miscellaneous", 6 },
                    { 7, 900.00m, new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9538), "New equipment purchase", 7 },
                    { 8, 600.00m, new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9541), "Operational costs", 8 },
                    { 9, 1100.00m, new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9545), "Maintenance expenses", 9 },
                    { 10, 100.00m, new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9548), "Small tools purchase", 10 },
                    { 11, 850.00m, new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9552), "Operational costs", 11 },
                    { 12, 650.00m, new DateTime(2024, 5, 28, 23, 17, 5, 280, DateTimeKind.Local).AddTicks(9555), "Repair services", 12 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "Documents",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Documents",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Documents",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Documents",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Documents",
                keyColumn: "Id",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Documents",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Documents",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Documents",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Documents",
                keyColumn: "Id",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "Documents",
                keyColumn: "Id",
                keyValue: 12);

            migrationBuilder.UpdateData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 1,
                column: "ReleaseDate",
                value: new DateTime(2024, 5, 22, 21, 21, 59, 442, DateTimeKind.Local).AddTicks(4771));

            migrationBuilder.UpdateData(
                table: "Equipments",
                keyColumn: "Id",
                keyValue: 2,
                column: "ReleaseDate",
                value: new DateTime(2024, 5, 22, 21, 21, 59, 442, DateTimeKind.Local).AddTicks(4804));

            migrationBuilder.UpdateData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 1,
                column: "Date",
                value: new DateTime(2024, 5, 22, 21, 21, 59, 442, DateTimeKind.Local).AddTicks(4840));

            migrationBuilder.UpdateData(
                table: "Finances",
                keyColumn: "Id",
                keyValue: 2,
                column: "Date",
                value: new DateTime(2024, 5, 22, 21, 21, 59, 442, DateTimeKind.Local).AddTicks(4843));

            migrationBuilder.UpdateData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 1,
                column: "BirthDate",
                value: new DateTime(1994, 5, 22, 21, 21, 59, 442, DateTimeKind.Local).AddTicks(4820));

            migrationBuilder.UpdateData(
                table: "Personnels",
                keyColumn: "Id",
                keyValue: 2,
                column: "BirthDate",
                value: new DateTime(1999, 5, 22, 21, 21, 59, 442, DateTimeKind.Local).AddTicks(4825));
        }
    }
}
