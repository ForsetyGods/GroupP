﻿using Microsoft.EntityFrameworkCore;
using MilitaryResourceManagement.API.Entity;
using MilitaryResourceManagement.API.Enum;

namespace MilitaryResourceManagement.API.Data
{
    public class MilitaryContext : DbContext
    {
        public MilitaryContext(DbContextOptions<MilitaryContext> options)
            : base(options)
        {
        }

        public DbSet<Equipment> Equipments { get; set; }
        public DbSet<Personnel> Personnels { get; set; }
        public DbSet<Document> Documents { get; set; }
        public DbSet<Finance> Finances { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Equipment>()
                .HasOne(e => e.Document)
                .WithMany(d => d.Equipments)
                .HasForeignKey(e => e.DocumentId);

            modelBuilder.Entity<Personnel>()
                .HasOne(p => p.Document)
                .WithMany(d => d.Personnels)
                .HasForeignKey(p => p.DocumentId);

            modelBuilder.Entity<Finance>()
                .HasOne(f => f.Equipment)
                .WithMany(e => e.Finances)
                .HasForeignKey(f => f.EquipmentId);
            modelBuilder.Entity<Document>().HasData(
         new Document { Id = 1, Title = "Operations Manual", FileUrl = "url_to_file1" },
         new Document { Id = 2, Title = "Maintenance Records", FileUrl = "url_to_file2" },
         new Document { Id = 3, Title = "Health and Safety Protocol", FileUrl = "url_to_file3" },
         new Document { Id = 4, Title = "Training Manual", FileUrl = "url_to_file4" },
         new Document { Id = 5, Title = "Logistics Overview", FileUrl = "url_to_file5" },
         new Document { Id = 6, Title = "Deployment Guidelines", FileUrl = "url_to_file6" },
         new Document { Id = 7, Title = "Equipment Usage Policy", FileUrl = "url_to_file7" },
         new Document { Id = 8, Title = "HR Policies", FileUrl = "url_to_file8" },
         new Document { Id = 9, Title = "Operational Strategies", FileUrl = "url_to_file9" },
         new Document { Id = 10, Title = "Communication Protocols", FileUrl = "url_to_file10" },
         new Document { Id = 11, Title = "IT Security Procedures", FileUrl = "url_to_file11" },
         new Document { Id = 12, Title = "Emergency Response Plan", FileUrl = "url_to_file12" }
     );

            modelBuilder.Entity<Equipment>().HasData(
                new Equipment { Id = 1, Name = "Tank", Type = "Vehicle", ReleaseDate = DateTime.Now, Status = EquipmentStatus.Operational, DocumentId = 1 },
                new Equipment { Id = 2, Name = "Jet Fighter", Type = "Aircraft", ReleaseDate = DateTime.Now, Status = EquipmentStatus.UnderMaintenance, DocumentId = 2 },
                new Equipment { Id = 3, Name = "Submarine", Type = "Naval", ReleaseDate = DateTime.Now, Status = EquipmentStatus.Operational, DocumentId = 3 },
                new Equipment { Id = 4, Name = "Rifle", Type = "Weapon", ReleaseDate = DateTime.Now, Status = EquipmentStatus.Operational, DocumentId = 4 },
                new Equipment { Id = 5, Name = "Helicopter", Type = "Aircraft", ReleaseDate = DateTime.Now, Status = EquipmentStatus.UnderMaintenance, DocumentId = 5 },
                new Equipment { Id = 6, Name = "Armored Vehicle", Type = "Vehicle", ReleaseDate = DateTime.Now, Status = EquipmentStatus.Operational, DocumentId = 6 },
                new Equipment { Id = 7, Name = "Drone", Type = "Aircraft", ReleaseDate = DateTime.Now, Status = EquipmentStatus.Operational, DocumentId = 7 },
                new Equipment { Id = 8, Name = "Missile", Type = "Weapon", ReleaseDate = DateTime.Now, Status = EquipmentStatus.Decommissioned, DocumentId = 8 },
                new Equipment { Id = 9, Name = "Warship", Type = "Naval", ReleaseDate = DateTime.Now, Status = EquipmentStatus.Operational, DocumentId = 9 },
                new Equipment { Id = 10, Name = "Artillery", Type = "Weapon", ReleaseDate = DateTime.Now, Status = EquipmentStatus.Operational, DocumentId = 10 },
                new Equipment { Id = 11, Name = "Cargo Truck", Type = "Vehicle", ReleaseDate = DateTime.Now, Status = EquipmentStatus.UnderMaintenance, DocumentId = 11 },
                new Equipment { Id = 12, Name = "Field Hospital", Type = "Support", ReleaseDate = DateTime.Now, Status = EquipmentStatus.Operational, DocumentId = 12 }
            );

            modelBuilder.Entity<Personnel>().HasData(
                new Personnel { Id = 1, FirstName = "John", LastName = "Doe", BirthDate = DateTime.Now.AddYears(-30), Rank = Rank.Captain, DocumentId = 1 },
                new Personnel { Id = 2, FirstName = "Jane", LastName = "Doe", BirthDate = DateTime.Now.AddYears(-25), Rank = Rank.Sergeant, DocumentId = 2 },
                new Personnel { Id = 3, FirstName = "Alice", LastName = "Wonder", BirthDate = DateTime.Now.AddYears(-22), Rank = Rank.Lieutenant, DocumentId = 3 },
                new Personnel { Id = 4, FirstName = "Bob", LastName = "Builder", BirthDate = DateTime.Now.AddYears(-35), Rank = Rank.Major, DocumentId = 4 },
                new Personnel { Id = 5, FirstName = "Charlie", LastName = "Day", BirthDate = DateTime.Now.AddYears(-28), Rank = Rank.Major, DocumentId = 5 },
                new Personnel { Id = 6, FirstName = "Diana", LastName = "Prince", BirthDate = DateTime.Now.AddYears(-32), Rank = Rank.General, DocumentId = 6 },
                new Personnel { Id = 7, FirstName = "Edward", LastName = "Scissorhands", BirthDate = DateTime.Now.AddYears(-29), Rank = Rank.Private, DocumentId = 7 },
                new Personnel { Id = 8, FirstName = "Fiona", LastName = "Shrek", BirthDate = DateTime.Now.AddYears(-26), Rank = Rank.Captain, DocumentId = 8 },
                new Personnel { Id = 9, FirstName = "George", LastName = "Jungle", BirthDate = DateTime.Now.AddYears(-24), Rank = Rank.Sergeant, DocumentId = 9 },
                new Personnel { Id = 10, FirstName = "Hannah", LastName = "Montana", BirthDate = DateTime.Now.AddYears(-21), Rank = Rank.Lieutenant, DocumentId = 10 },
                new Personnel { Id = 11, FirstName = "Ian", LastName = "Mckellen", BirthDate = DateTime.Now.AddYears(-34), Rank = Rank.Major, DocumentId = 11 },
                new Personnel { Id = 12, FirstName = "Julia", LastName = "Roberts", BirthDate = DateTime.Now.AddYears(-27), Rank = Rank.Colonel, DocumentId = 12 }
            );

            modelBuilder.Entity<Finance>().HasData(
                new Finance { Id = 1, Amount = 1000.00m, Date = DateTime.Now, Description = "Purchase of equipment", EquipmentId = 1 },
                new Finance { Id = 2, Amount = 500.00m, Date = DateTime.Now, Description = "Maintenance expenses", EquipmentId = 2 },
                new Finance { Id = 3, Amount = 1200.00m, Date = DateTime.Now, Description = "Operational costs", EquipmentId = 3 },
                new Finance { Id = 4, Amount = 750.00m, Date = DateTime.Now, Description = "Repair services", EquipmentId = 4 },
                new Finance { Id = 5, Amount = 250.00m, Date = DateTime.Now, Description = "Fuel expenses", EquipmentId = 5 },
                new Finance { Id = 6, Amount = 300.00m, Date = DateTime.Now, Description = "Miscellaneous", EquipmentId = 6 },
                new Finance { Id = 7, Amount = 900.00m, Date = DateTime.Now, Description = "New equipment purchase", EquipmentId = 7 },
                new Finance { Id = 8, Amount = 600.00m, Date = DateTime.Now, Description = "Operational costs", EquipmentId = 8 },
                new Finance { Id = 9, Amount = 1100.00m, Date = DateTime.Now, Description = "Maintenance expenses", EquipmentId = 9 },
                new Finance { Id = 10, Amount = 100.00m, Date = DateTime.Now, Description = "Small tools purchase", EquipmentId = 10 },
                new Finance { Id = 11, Amount = 850.00m, Date = DateTime.Now, Description = "Operational costs", EquipmentId = 11 },
                new Finance { Id = 12, Amount = 650.00m, Date = DateTime.Now, Description = "Repair services", EquipmentId = 12 }
            );

        }
    }


}