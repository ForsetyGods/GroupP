﻿using Microsoft.AspNetCore.Mvc;
using MilitaryResourceManagement.API.Entity;
using MilitaryResourceManagement.API.Repositories;

namespace MilitaryResourceManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FinanceController : ControllerBase
    {
        private readonly IGenericRepository<Finance> _repository;

        public FinanceController(IGenericRepository<Finance> repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<IEnumerable<Finance>> GetAll()
        {
            return await _repository.GetAllAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Finance>> GetById(int id)
        {
            var finance = await _repository.GetByIdAsync(id);
            if (finance == null)
            {
                return NotFound();
            }
            return finance;
        }

        [HttpPost]
        public async Task<ActionResult> Create([FromBody] Finance finance)
        {
            if (finance == null)
            {
                return BadRequest("Finance is null.");
            }

            await _repository.AddAsync(finance);
            return CreatedAtAction(nameof(GetById), new { id = finance.Id }, finance);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Update(int id, [FromBody] Finance finance)
        {
            if (id != finance.Id)
            {
                return BadRequest();
            }

            await _repository.UpdateAsync(finance);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.DeleteAsync(id);
            return NoContent();
        }
    }
}
