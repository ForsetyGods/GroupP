﻿using Microsoft.AspNetCore.Mvc;
using MilitaryResourceManagement.API.Entity;
using MilitaryResourceManagement.API.Repositories;
using MilitaryResourceManagement.API.Services;

namespace MilitaryResourceManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DocumentController : ControllerBase
    {
        private readonly IGenericRepository<Document> _repository;
        private readonly IBlobStorageService _blobStorageService;

        public DocumentController(IGenericRepository<Document> repository, IBlobStorageService blobStorageService)
        {
            _repository = repository;
            _blobStorageService = blobStorageService;
        }

        [HttpGet]
        public async Task<IEnumerable<Document>> GetAll()
        {
            return await _repository.GetAllAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Document>> GetById(int id)
        {
            var document = await _repository.GetByIdAsync(id);
            if (document == null)
            {
                return NotFound();
            }
            return document;
        }

        [HttpPost]
        public async Task<ActionResult> Create([FromBody] Document document)
        {
            if (document == null)
            {
                return BadRequest("Document is null.");
            }

            await _repository.AddAsync(document);
            return CreatedAtAction(nameof(GetById), new { id = document.Id }, document);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Update(int id, [FromBody] Document document)
        {
            if (id != document.Id)
            {
                return BadRequest();
            }

            await _repository.UpdateAsync(document);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.DeleteAsync(id);
            return NoContent();
        }

        [HttpPost("upload")]
        public async Task<ActionResult> UploadDocument([FromForm] IFormFile file, [FromForm] string title)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("Invalid file.");
            }

            var documentUrl = await _blobStorageService.UploadFileAsync(file);
            var document = new Document
            {
                Title = title,
                FileUrl = documentUrl
            };

            await _repository.AddAsync(document);

            return Ok(new { Url = documentUrl });
        }
    }
}
