﻿using Microsoft.AspNetCore.Mvc;
using MilitaryResourceManagement.API.Entity;
using MilitaryResourceManagement.API.Repositories;
using MilitaryResourceManagement.API.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MilitaryResourceManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EquipmentController : ControllerBase
    {
        private readonly IGenericRepository<Equipment> _repository;
        private readonly IMessageService _messageService;

        public EquipmentController(IGenericRepository<Equipment> repository, IMessageService messageService)
        {
            _repository = repository;
            _messageService = messageService;
        }

        [HttpGet]
        public async Task<IEnumerable<Equipment>> GetAll()
        {
            return await _repository.GetAllAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Equipment>> GetById(int id)
        {
            var equipment = await _repository.GetByIdAsync(id);
            if (equipment == null)
            {
                return NotFound();
            }
            return equipment;
        }

        [HttpPost]
        public async Task<ActionResult> Create([FromBody] Equipment equipment)
        {
            if (equipment == null)
            {
                return BadRequest("Equipment is null.");
            }

            await _repository.AddAsync(equipment);
            await _messageService.SendMessageAsync($"New equipment added: {equipment.Name}");

            return CreatedAtAction(nameof(GetById), new { id = equipment.Id }, equipment);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Update(int id, [FromBody] Equipment equipment)
        {
            if (id != equipment.Id)
            {
                return BadRequest();
            }

            await _repository.UpdateAsync(equipment);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.DeleteAsync(id);
            return NoContent();
        }
    }

}
