﻿using Microsoft.AspNetCore.Mvc;
using MilitaryResourceManagement.API.Entity;
using MilitaryResourceManagement.API.Repositories;

namespace MilitaryResourceManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonnelController : ControllerBase
    {
        private readonly IGenericRepository<Personnel> _repository;

        public PersonnelController(IGenericRepository<Personnel> repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<IEnumerable<Personnel>> GetAll()
        {
            return await _repository.GetAllAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Personnel>> GetById(int id)
        {
            var personnel = await _repository.GetByIdAsync(id);
            if (personnel == null)
            {
                return NotFound();
            }
            return personnel;
        }

        [HttpPost]
        public async Task<ActionResult> Create([FromBody] Personnel personnel)
        {
            if (personnel == null)
            {
                return BadRequest("Personnel is null.");
            }

            await _repository.AddAsync(personnel);
            return CreatedAtAction(nameof(GetById), new { id = personnel.Id }, personnel);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Update(int id, [FromBody] Personnel personnel)
        {
            if (id != personnel.Id)
            {
                return BadRequest();
            }

            await _repository.UpdateAsync(personnel);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            await _repository.DeleteAsync(id);
            return NoContent();
        }
    }
}
