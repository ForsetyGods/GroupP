﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MilitaryResourceManagement.API.Controllers
{
     public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Equipments()
        {
            return RedirectToAction("Index", "Equipment");
        }

        public IActionResult Personnels()
        {
            return RedirectToAction("Index", "Personnel");
        }

        public IActionResult Documents()
        {
            return RedirectToAction("Index", "Document");
        }

        public IActionResult Finances()
        {
            return RedirectToAction("Index", "Finance");
        }
    }
}
