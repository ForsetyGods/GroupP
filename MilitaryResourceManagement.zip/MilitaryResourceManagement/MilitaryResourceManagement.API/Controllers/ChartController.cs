﻿using Microsoft.AspNetCore.Mvc;
using MilitaryResourceManagement.API.Services;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using XPlot.Plotly;

namespace MilitaryManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChartController : ControllerBase
    {
        private readonly FinanceService _financeService;
        private readonly IBlobStorageService _blobStorageService;

        public ChartController(FinanceService financeService, IBlobStorageService blobStorageService)
        {
            _financeService = financeService;
            _blobStorageService = blobStorageService;
        }

        [HttpGet("expenses")]
        public async Task<IActionResult> GetExpensesChart()
        {
            var equipmentExpenses = await _financeService.GetEquipmentExpensesAsync();
            var personnelExpenses = await _financeService.GetPersonnelExpensesAsync();

            var months = equipmentExpenses.Keys.Concat(personnelExpenses.Keys).Distinct().OrderBy(m => m).ToArray();
            var equipmentValues = months.Select(m => equipmentExpenses.ContainsKey(m) ? equipmentExpenses[m] : 0).ToArray();
            var personnelValues = months.Select(m => personnelExpenses.ContainsKey(m) ? personnelExpenses[m] : 0).ToArray();

            var equipmentTrace = new Scatter
            {
                name = "Equipment",
                x = months,
                y = equipmentValues,
                mode = "lines+markers"
            };

            var personnelTrace = new Scatter
            {
                name = "Personnel",
                x = months,
                y = personnelValues,
                mode = "lines+markers"
            };

            var chart = Chart.Plot(new[] { equipmentTrace, personnelTrace });
            var chartHtml = chart.GetHtml();

            var chartFilePath = Path.Combine(Path.GetTempPath(), "expensesChart.html");
            await System.IO.File.WriteAllTextAsync(chartFilePath, chartHtml);

            var chartUrl = await _blobStorageService.UploadFileAsync(chartFilePath);

            return Ok(new { ChartUrl = chartUrl });
        }
    }
}
