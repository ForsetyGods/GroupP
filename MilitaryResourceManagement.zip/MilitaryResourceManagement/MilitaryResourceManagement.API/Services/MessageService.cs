﻿using Azure.Messaging.ServiceBus;

namespace MilitaryResourceManagement.API.Services
{
    public class MessageService : IMessageService
    {
        private readonly string _connectionString;
        private readonly string _queueName;

        public MessageService(string connectionString, string queueName)
        {
            _connectionString = connectionString;
            _queueName = queueName;
        }

        public async Task SendMessageAsync(string message)
        {
            await using var client = new ServiceBusClient(_connectionString);
            ServiceBusSender sender = client.CreateSender(_queueName);

            ServiceBusMessage busMessage = new ServiceBusMessage(message);
            await sender.SendMessageAsync(busMessage);
        }
    }

}
