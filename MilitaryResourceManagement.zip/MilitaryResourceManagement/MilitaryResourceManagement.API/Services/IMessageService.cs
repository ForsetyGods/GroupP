﻿namespace MilitaryResourceManagement.API.Services
{
    public interface IMessageService
    {
        Task SendMessageAsync(string message);
    }
}
