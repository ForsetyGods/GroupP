﻿using MilitaryResourceManagement.API.Entity;
using MilitaryResourceManagement.API.Repositories;

namespace MilitaryResourceManagement.API.Services
{
    public class FinanceService
    {
        private readonly IGenericRepository<Finance> _repository;

        public FinanceService(IGenericRepository<Finance> repository)
        {
            _repository = repository;
        }

        public async Task<Dictionary<string, decimal>> GetEquipmentExpensesAsync()
        {
            var finances = await _repository.GetAllAsync();
            return finances
                .Where(f => f.Description.Contains("equipment", StringComparison.OrdinalIgnoreCase))
                .GroupBy(f => f.Date.ToString("MMMM yyyy"))
                .ToDictionary(g => g.Key, g => g.Sum(f => f.Amount));
        }

        public async Task<Dictionary<string, decimal>> GetPersonnelExpensesAsync()
        {
            var finances = await _repository.GetAllAsync();
            return finances
                .Where(f => f.Description.Contains("personnel", StringComparison.OrdinalIgnoreCase))
                .GroupBy(f => f.Date.ToString("MMMM yyyy"))
                .ToDictionary(g => g.Key, g => g.Sum(f => f.Amount));
        }
    }


}
