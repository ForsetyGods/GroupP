﻿namespace MilitaryResourceManagement.API.Services
{
    public interface IBlobStorageService
    {
        Task<string> UploadFileAsync(IFormFile file);
        Task<string> UploadFileAsync(string filePath);

    }
}
