﻿using System.ComponentModel.DataAnnotations;

namespace MilitaryResourceManagement.API.Enum
{
    public enum EquipmentStatus
    {
        [Display(Name = "Operational")]
        Operational,

        [Display(Name = "Under Maintenance")]
        UnderMaintenance,

        [Display(Name = "Decommissioned")]
        Decommissioned

    }
}
