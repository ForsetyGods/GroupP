﻿using System.ComponentModel.DataAnnotations;

namespace MilitaryResourceManagement.API.Enum
{
    public enum Rank
    {
        [Display(Name = "Private")]
        Private,

        [Display(Name = "Sergeant")]
        Sergeant,

        [Display(Name = "Lieutenant")]
        Lieutenant,

        [Display(Name = "Captain")]
        Captain,

        [Display(Name = "Major")]
        Major,

        [Display(Name = "Colonel")]
        Colonel,

        [Display(Name = "General")]
        General
    }

}
