using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using MilitaryResourceManagement.API.Repositories;
using MilitaryResourceManagement.API.Services;
using Microsoft.OpenApi.Models;
using MilitaryResourceManagement.API.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

// Add DbContext with connection string from appsettings.json
builder.Services.AddDbContext<MilitaryContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("MilitaryDatabase")));

// Register generic repository
builder.Services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));

// Register other services
builder.Services.AddScoped<FinanceService>();
builder.Services.AddScoped<IMessageService, MessageService>(sp =>
    new MessageService(builder.Configuration["Azure:ServiceBus:ConnectionString"], builder.Configuration["Azure:ServiceBus:QueueName"]));
builder.Services.AddScoped<IBlobStorageService, BlobStorageService>(sp =>
    new BlobStorageService(builder.Configuration["Azure:BlobStorage:ConnectionString"], builder.Configuration["Azure:BlobStorage:ContainerName"]));

// Add CORS policy
builder.Services.AddCors(options =>
{
    options.AddPolicy("CorsPolicy", builder =>
    {
        builder.AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader();
    });
});

// Add Swagger
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Military Resource Management API", Version = "v1" });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseCors("CorsPolicy");
app.UseAuthorization();

// Enable middleware to serve generated Swagger as a JSON endpoint.
app.UseSwagger();

// Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
// specifying the Swagger JSON endpoint.
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Military Resource Management API v1");
    c.RoutePrefix = string.Empty;  // Set Swagger UI at the root (e.g. https://localhost:7211/)
});

app.MapControllers();

app.Run();
