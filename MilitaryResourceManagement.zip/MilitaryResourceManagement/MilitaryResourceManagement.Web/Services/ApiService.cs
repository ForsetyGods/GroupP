﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using MilitaryResourceManagement.API.Entity;

namespace MilitaryResourceManagement.Web.Services
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;

        public ApiService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        // Equipment Methods
        public async Task<IEnumerable<Equipment>> GetEquipmentsAsync()
        {
            return await _httpClient.GetFromJsonAsync<IEnumerable<Equipment>>("api/equipment");
        }

        public async Task<Equipment> GetEquipmentByIdAsync(int id)
        {
            return await _httpClient.GetFromJsonAsync<Equipment>($"api/equipment/{id}");
        }

        public async Task AddEquipmentAsync(Equipment equipment)
        {
            await _httpClient.PostAsJsonAsync("api/equipment", equipment);
        }

        public async Task UpdateEquipmentAsync(Equipment equipment)
        {
            await _httpClient.PutAsJsonAsync($"api/equipment/{equipment.Id}", equipment);
        }

        public async Task DeleteEquipmentAsync(int id)
        {
            await _httpClient.DeleteAsync($"api/equipment/{id}");
        }

        // Document Methods
        public async Task<IEnumerable<Document>> GetDocumentsAsync()
        {
            return await _httpClient.GetFromJsonAsync<IEnumerable<Document>>("api/document");
        }

        public async Task<Document> GetDocumentByIdAsync(int id)
        {
            return await _httpClient.GetFromJsonAsync<Document>($"api/document/{id}");
        }

        public async Task AddDocumentAsync(Document document)
        {
            await _httpClient.PostAsJsonAsync("api/document", document);
        }

        public async Task UpdateDocumentAsync(Document document)
        {
            await _httpClient.PutAsJsonAsync($"api/document/{document.Id}", document);
        }

        public async Task DeleteDocumentAsync(int id)
        {
            await _httpClient.DeleteAsync($"api/document/{id}");
        }

        // Personnel Methods
        public async Task<IEnumerable<Personnel>> GetPersonnelsAsync()
        {
            return await _httpClient.GetFromJsonAsync<IEnumerable<Personnel>>("api/personnel");
        }

        public async Task<Personnel> GetPersonnelByIdAsync(int id)
        {
            return await _httpClient.GetFromJsonAsync<Personnel>($"api/personnel/{id}");
        }

        public async Task AddPersonnelAsync(Personnel personnel)
        {
            await _httpClient.PostAsJsonAsync("api/personnel", personnel);
        }

        public async Task UpdatePersonnelAsync(Personnel personnel)
        {
            await _httpClient.PutAsJsonAsync($"api/personnel/{personnel.Id}", personnel);
        }

        public async Task DeletePersonnelAsync(int id)
        {
            await _httpClient.DeleteAsync($"api/personnel/{id}");
        }
    }
}
