using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MilitaryResourceManagement.API.Services;
using MilitaryResourceManagement.Web.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

// Register HttpClient and other services
builder.Services.AddHttpClient<ApiService>(client =>
{
    client.BaseAddress = new Uri("https://localhost:44369"); // ���������, ��� ���� URL ��������� � URL ������ API
});


builder.Services.AddScoped<IMessageService, MessageService>(sp =>
    new MessageService(builder.Configuration["Azure:ServiceBus:ConnectionString"], builder.Configuration["Azure:ServiceBus:QueueName"]));
builder.Services.AddScoped<IBlobStorageService, BlobStorageService>(sp =>
    new BlobStorageService(builder.Configuration["Azure:BlobStorage:ConnectionString"], builder.Configuration["Azure:BlobStorage:ContainerName"]));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
